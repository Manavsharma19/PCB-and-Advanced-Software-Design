package ast;

public class IfStmt extends Node {

	public IfStmt(int pos) {
		super(pos);
	}

	@Override
	public String toString() {
		return "IfStmt ";
	}

	public String codeGen(Code c) {
		System.out.println("ifstmt -codegen");
		if (children.size() != 2)
			System.out.println("need a condition and a statement for if");

		// Generate code for the condition
		String conditionReg = children.get(0).codeGen(c);

		// Load the value of the condition
		c.code += "ldr r0, " + conditionReg + "\n";

		// Compare the value of the condition
		c.code += "cmp r0, #0\n";

		// Branch to the else part if the condition is false
		c.code += "beq else\n";

		// Generate code for the true part
		children.get(1).codeGen(c);

		// Label for the else part
		c.code += "else:\n";

		return null;
	}

	public Variable eval(Context c) {
		System.out.println("if -eval");
		if (children.size() < 2)
			System.out.println("need a condition and a statement for if");

		Variable condition = children.get(0).eval(c);
		if (condition.val != 0) {
			Variable statement = children.get(1).eval(c);
		}
		return null;
	}
}
