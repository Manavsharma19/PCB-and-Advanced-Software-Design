package ast;

public class WhileStmt extends Node {

	public WhileStmt(int pos) {
		super(pos);
	}

	@Override
	public String toString() {
		return "WhileStmt ";
	}

	public String codeGen(Code c) {
		System.out.println("While stmt -codegen");
		if (children.size() != 2)
			System.out.println("need a condition and a statement for while");

		// Label for the beginning of the loop
		c.code += "loop:\n";

		// Generate code for the condition
		String conditionReg = children.get(0).codeGen(c);

		// Load the value of the condition
		c.code += "ldr r0, " + conditionReg + "\n";

		// Compare the value of the condition
		c.code += "cmp r0, #0\n";

		// Branch to the end of the loop if the condition is false
		c.code += "beq endloop\n";

		// Generate code for the body of the loop
		children.get(1).codeGen(c);

		// Unconditional branch back to the beginning of the loop
		c.code += "b loop\n";

		// Label for the end of the loop
		c.code += "endloop:\n";

		return null;
	}

	public Variable eval(Context c) {
		System.out.println("while -eval");
		if (children.size() < 2)
			System.out.println("need a condition and a statement for while");

		while (children.get(0).eval(c).val != 0) {
			// Execute the body of the loop
			children.get(1).eval(c);
		}
		return null;
	}
}
